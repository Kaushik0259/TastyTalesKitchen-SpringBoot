package com.ttk.exception;

public class FoodPhototosNotFoundException extends RuntimeException {
	
	public FoodPhototosNotFoundException(String message)
	{
		super(message);

	}

}
