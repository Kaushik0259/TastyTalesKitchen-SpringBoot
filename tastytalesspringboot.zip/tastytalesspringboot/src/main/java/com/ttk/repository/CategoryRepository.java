package com.ttk.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ttk.entity.Category;

public interface CategoryRepository extends JpaRepository<Category, Integer>{

}
