package com.ttk.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ttk.entity.RecipePost;

public interface RecipePostRepository extends JpaRepository<RecipePost, Integer>{

}
