package com.ttk.entity;

import java.util.Date;

import org.springframework.data.annotation.CreatedDate;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
public class BookShelf {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int bookid;

	@Column(length=25, nullable = false)
	@NotBlank(message = "Book title cannot be blank")
	private String btitle;

	@Column(length=25)
	@NotBlank(message = "Author cannot be blank")
	private String bauthor;

	@Column(length=25, nullable = false, unique = true)
	@NotNull(message = "isbn cannot be null")
	private long isbn;

	@Column(length=50, nullable = false)
	@NotBlank(message = "Publication date cannot be null")
	private Date publicationdate;

	@CreatedDate
	private Date createdat;
	
//	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@JoinColumn(name= "uid")
//	@JsonBackReference
//	private User user;
//	
//	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@JoinColumn(name= "aid")
//	@JsonBackReference
//	private Admin admin;
//	
//	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
//	@JoinColumn(name= "paymentId")
//	@JsonBackReference
//	private Payment paymentId;
	
}

