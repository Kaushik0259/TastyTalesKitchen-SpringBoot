package com.ttk.entity;

import org.springframework.data.annotation.CreatedDate;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Entity
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int uid;

	@Column(length=25, nullable = false)
	@NotBlank(message = "User Name cannot be blank")
	private String ufname;
	//firstName
	
	@Column(length=25)
	@NotBlank(message = "User Last Name cannot be blank")
	private String ulname;

	@Column(length=10, nullable = false, unique = true)
	@NotNull(message = "User phone cannot be null")
	//@Pattern(regexp = "[6789]{1}[0-9]{9}")
	private long uphone;//pattern for phone no

	@Column(length=50, nullable = false, unique = true)
	@NotBlank(message = "User Email cannot be blank")
	@Email(message = "Email is incorrect")
	private String uemail;

	@Column(length=50, nullable = false)
	@NotBlank(message = "User Address cannot be blank")
	private String uaddr;

	@CreatedDate
	private Date createdat;//createdAt
//	
//	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
//	@JsonManagedReference
//	private List<BookShelf> book;
//	
//	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
//	@JsonManagedReference
//	private List<FoodPhotos> photo;
//	
//	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
//	@JsonManagedReference
//	private List<RecipePost> recipe;
//	
//	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
//	@JsonManagedReference
//	private List<VideosFeed> video;
//	
//	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
//	@JsonManagedReference
//	private List<Category> category;
//	
//	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
//	@JsonManagedReference
//	private List<Payment> payment;
//	
//	@OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
//	@JsonManagedReference
//	private List<Feedback> feedback;

}
