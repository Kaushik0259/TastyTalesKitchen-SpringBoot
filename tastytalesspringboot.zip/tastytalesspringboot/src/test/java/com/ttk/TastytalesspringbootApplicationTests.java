package com.ttk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TastytalesspringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
